function add(){
 let a=Number(document.getElementById('a').value);
 let b=Number(document.getElementById('b').value);
 document.getElementById('result').innerHTML="Result: "+(a+b);
}
