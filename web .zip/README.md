# Web Technology Practicals

This repository contains basic practical programs for:

- HTML basics, tables, forms, and semantic elements
- CSS styling, selectors, box model, and responsiveness
- JavaScript calculator and DOM manipulation

## Files
- index.html
- style.css
- script.js

## Deployment
Upload this project to GitHub and enable GitHub Pages to host your site.
